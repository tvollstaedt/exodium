echo off

cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo  Druecke
echo   1  um Big Red Adventure mit Dosbox zu spielen
echo   2  um Big Red Adventure mit ScummVM zu spielen
echo.
..\..\..\..\util\choice /C:12 /N Bitte waehlen:

if errorlevel = 2 goto scummvm
if errorlevel = 1 goto dosbox

:dosbox
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:scummvm
cd ..
cd ..
cd ..
cd ..
cls
echo.
echo  Druecke
echo   1  um Sound Blaster fuer Musik zu nutzen
echo   2  um Sound Canvas fuer Musik zu nutzen
echo.
.\util\choice /C:12 /N Bitte waehlen:

if errorlevel = 2 goto svmsc55
if errorlevel = 1 goto svmsb

:svmsb
.\util\setconsole.exe /minimize
".\emulators\scummvm\scummvm.exe" --no-console -F -g3x --aspect-ratio --language=de -p.\eXoDOS\!german\bigred\scummvm\ bra
goto end

:svmsc55
.\util\setconsole.exe /minimize
".\emulators\scummvm\scummvm.exe" --no-console -F -g3x -efluidsynth --soundfont=.\mt32\soundcanvas.sf2 --aspect-ratio --language=de -p.\eXoDOS\!german\bigred\scummvm\ bra
goto end

:end