echo off
cd %VAR%
..\..\..\..\util\setconsole.exe /reset
echo.
echo  Druecke
echo  1  um Cruise for a Corpse mit DOSBox zu spielen
echo  2  um Cruise for a Corpse mit ScummVM zu spielen
echo.
..\..\..\..\util\choice /C:12 /N Bitte waehlen:

if errorlevel = 2 goto scummvm
if errorlevel = 1 goto dosbox

:dosbox
..\..\..\..\util\setconsole.exe /minimize
cd ..
cd ..
cd ..
cd ..
".\emulators\dosbox\%dosbox%" -conf "%var%\dosbox.conf" -conf ".\emulators\dosbox\options.conf" -noconsole -exit -nomenu
del stdout.txt
del stderr.txt
if exist glide.* del glide.*
if exist .\eXoDOS\CWSDPMI.swp del .\eXoDOS\CWSDPMI.swp
goto end

:scummvm
cd ..
cd ..
cd ..
cd ..
cls
echo.
echo  Druecke
echo  1  um Sound Blaster fuer Musik zu nutzen
echo  1  um MT-32 fuer Musik zu nutzen
echo.
.\util\choice /C:12 /N Bitte waehlen:

if errorlevel = 2 goto svmmt32
if errorlevel = 1 goto svmsb

:svmsb
.\util\setconsole.exe /minimize
".\emulators\scummvm\scummvm.exe" --no-console -F -g3x --aspect-ratio --language=de -p.\eXoDOS\!german\ccorpse\scummvm\ cruise
goto end

:svmmt32
.\util\setconsole.exe /minimize
".\emulators\scummvm\scummvm.exe" --no-console -F -g3x -emt32 --extrapath=.\mt32\ --aspect-ratio --language=de -p.\eXoDOS\!german\ccorpse\scummvm\ cruise
goto end

:end