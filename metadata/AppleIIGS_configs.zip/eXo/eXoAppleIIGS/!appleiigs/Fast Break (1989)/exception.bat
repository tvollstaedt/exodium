echo off
SET DISK1=Game.2mg
SET DISK2=
SET DISKS=1
cd %VAR%