echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo When asked to insert disk 2, just
echo press enter.
echo.
pause
..\..\..\util\setconsole.exe /minimize