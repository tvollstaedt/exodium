echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game double click "Start". 
echo.
echo When asked, choose "Kinnar Space Academy" to
echo create and edit characters or teams. To play
echo the game choose "Crylla". Press Alt+Q to exit
echo either of these programs.
echo.
pause
..\..\..\util\setconsole.exe /minimize