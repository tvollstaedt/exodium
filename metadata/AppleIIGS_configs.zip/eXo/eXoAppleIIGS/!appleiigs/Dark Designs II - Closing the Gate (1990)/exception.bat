echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game double click "Dark2.GS.System"
echo.
echo You can reset the game maps and clear the characters 
echo by pressing "Ctrl+r" while on the title screen if desired.
echo.
pause
..\..\..\util\setconsole.exe /minimize