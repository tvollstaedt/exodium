echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo When asked for the slot that your character disk is in
echo select "Slot 5, Drive 1".
echo.
echo If you wish to transfer a save from Bard's Tale I, make sure
echo BT1 is installed, select the transfer option in BT2, when asked
echo for a source disk select "Slot 5, Drive 2" and for destination
echo select "Slot 5, Drive 1".
echo.
pause
..\..\..\util\setconsole.exe /minimize