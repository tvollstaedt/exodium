echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Double click "Space.Academy" to enter the Kinnar
echo Space Academy where you create and edit characters
echo or teams. To play the game choose "Cryllan.Mission".
echo Press Alt+Q to exit either of these programs.
echo.
pause
..\..\..\util\setconsole.exe /minimize