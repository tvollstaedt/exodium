echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
cls
echo.
echo Press 1 for Cribbage King
echo Press 2 for Gin King
echo.
..\..\..\util\choice /C:12 /N Please Choose:

if errorlevel = 2 goto gin
if errorlevel = 1 goto crib

:crib
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=crib.txt
goto end

:gin
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=gin.txt
goto end

:end