echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo When you are asked to insert Disk 2, press "F4".
echo From this menu select "Disk Configuration". Select
echo "s5d2", then select "Disk2.2mg".
echo.
pause
..\..\..\util\setconsole.exe /minimize