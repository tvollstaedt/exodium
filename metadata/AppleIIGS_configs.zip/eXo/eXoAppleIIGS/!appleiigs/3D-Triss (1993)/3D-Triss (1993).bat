@echo off
..\..\..\util\setconsole.exe /minimize
@set var=%cd%
for %%I in (.) do set GameDir=%%~nxI
for %%f in (*^).bat) do set GameName2=%%f
set GameName=%GameName2:~0,-4%
set IndexName=%GameName:~0,-7%
cd ..
..\..\util\unzip -o ..\..\util\configs.zip "%GameName%/*.txt"
cd ..
cd ..
cls
.\util\Launch_IIGS.bat