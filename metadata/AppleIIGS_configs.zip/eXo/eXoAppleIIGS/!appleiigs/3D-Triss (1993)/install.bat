@echo off
set FOLDER=%CD%
..\..\..\util\install_IIGS.bat
:exit