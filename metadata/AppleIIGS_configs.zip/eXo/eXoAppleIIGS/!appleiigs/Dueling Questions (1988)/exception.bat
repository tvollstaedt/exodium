SET DISK1=Game.2mg
SET DISK2=
SET DISKS=1
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game double click "Dueling.Quest"
echo.
pause
..\..\..\util\setconsole.exe /minimize
