echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
cls
echo.
echo Press 1 to play Geometry Part 1
echo Press 2 to play Geometry Part 2
echo.
..\..\..\util\choice /C:12 /N Please Choose:

if errorlevel = 2 goto part2
if errorlevel = 1 goto part1

:part1
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=config2.txt
goto end

:part2
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=config1.txt
goto end

:end