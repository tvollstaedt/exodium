echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo If you wish to read the authors notes double click "Explorer.Docs",
echo otherwise to play the modules created by the author of ExplorerGS 
echo double click "ExplorerGS". Under "File", "Load Game" you can then 
echo select "Islands", "Lyle.Valley", or "Nor.Forest". You then need to 
echo "Load Character" and will need to double click the "Characters"
echo folder to then select one. Now you can select "Game" and "Play".
echo.
echo To play other user created adventures you can load ExplorerGS as above
echo and this time double click to "Adventures" folder when selecting 
echo "Load Game". Select a module and then follow the other instructions 
echo above re loading a character (click the little down arrow above the 
echo folder selection to navigate back up the folder tree to get to the 
echo "Characters" folder) and starting the game.
echo.
echo The other option is to play a user created total conversion adventure.
echo To do this instead of running "ExplorerGS", open one of the folders on the
echo right under the heading "Adventures2". Each of these will have a file with
echo "GS" in the name and, if the module author wrote some notes, a document file
echo next to it you can open to read. Run the "GS" file and then follow the other
echo instructions as above to open the module found in the same folder and load a
echo character.
echo.
echo Lastly, you can create your own characters or modules by using "GameMakerGS"
echo which has some documentation in the file next to the executable. 
echo.
pause
..\..\..\util\setconsole.exe /minimize