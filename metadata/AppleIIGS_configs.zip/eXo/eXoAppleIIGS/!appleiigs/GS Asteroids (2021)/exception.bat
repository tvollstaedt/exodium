echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Rotate Left\Right with F1 and F2.
echo.
pause
..\..\..\util\setconsole.exe /minimize