echo off
SET DISK1=Game.hdv
SET DISK2=
SET DISKS=1
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To access the save\load menu when in game you need to use the key 
echo combination LeftCtrl+LeftAlt+F3.
echo.
pause
..\..\..\util\setconsole.exe /minimize