echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Double click "First.Shapes" to start the game.
echo.
pause
..\..\..\util\setconsole.exe /minimize