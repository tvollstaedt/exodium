echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo When asked for the slot that your character disk is in
echo select "Slot 5, Drive 1"
echo.
pause
..\..\..\util\setconsole.exe /minimize