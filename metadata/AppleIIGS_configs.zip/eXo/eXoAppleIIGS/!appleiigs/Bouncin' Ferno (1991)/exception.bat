echo off
SET DISK1=Game.po
SET DISK2=
SET DISKS=1
cd %VAR%
