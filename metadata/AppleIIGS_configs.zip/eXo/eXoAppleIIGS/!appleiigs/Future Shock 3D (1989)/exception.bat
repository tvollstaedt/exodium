echo off
SET DISK1=Game.po
SET DISK2=
SET DISKS=1
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo This game was made for a peripheral called the "Future Pad".
echo The game used the device to make the in game ball jump. A
echo hacked version that bypasses the "Future Pad" interface 
echo has been made, and this is the version included.
echo.
echo To control the ball use the mouse to move and "2" on the
echo numpad to jump.
echo.
pause
..\..\..\util\setconsole.exe /minimize