echo off
.\util\capslock.exe on
