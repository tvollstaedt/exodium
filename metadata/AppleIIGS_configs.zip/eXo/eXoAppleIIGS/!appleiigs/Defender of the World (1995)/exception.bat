echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game double click the "DOTW" icon.
echo.
echo Fire guns with F1 and use powerups with F2.
echo.
pause
..\..\..\util\setconsole.exe /minimize