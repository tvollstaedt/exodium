echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo After you get past the title screen you will get a
echo message to "Insert Data Disk". Select "Abort" and then
echo double click the "Level" folder. Select the script you
echo wish to play.
echo.
echo There is also a sound issue. In order to fix it press
echo "Cancel" when you can choose 1 or 2 players. Press Alt+s,
echo and then drag the volume slider up and press ok. Then
echo press Alt+n to get back to the player number choice.
echo.
pause
..\..\..\util\setconsole.exe /minimize