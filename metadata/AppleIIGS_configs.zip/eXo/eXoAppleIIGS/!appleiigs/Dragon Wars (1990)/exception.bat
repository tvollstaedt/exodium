echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo The game starts with an inbuilt default party.
echo Some utility commands inlcluding delete and 
echo create characters are:
echo.
echo d = Delete character
echo z = Create new character
echo alt+a = Save game
echo alt+q = Quit
echo alt+o = Restore game
echo alt+n = New game
echo.
pause
..\..\..\util\setconsole.exe /minimize