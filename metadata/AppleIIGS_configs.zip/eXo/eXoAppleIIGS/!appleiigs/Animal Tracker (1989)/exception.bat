echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game, double click
echo "AnimalTracker".
echo.
echo If during play you are asked to
echo insert another disk, select "ok".
echo.
pause
..\..\..\util\setconsole.exe /minimize