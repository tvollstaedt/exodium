echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Double click "Startup" to play the game.
echo.
pause
..\..\..\util\setconsole.exe /minimize