echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo To start the game double click "Castle.Metacus". 
echo If you read "About.Metacus", to exit the document
echo select "Quit" under the "File" menu.
echo.
pause
..\..\..\util\setconsole.exe /minimize