@echo off
cd %VAR%
..\..\..\util\setconsole.exe /reset
cls
echo.
echo Press 1 to play Designasaurus: Walk a Dinosaur
echo Press 2 to play Designasaurus: Build a Dinosaur
echo.
..\..\..\util\choice /C:12 /N Please Choose:

if errorlevel = 2 goto build
if errorlevel = 1 goto walk

:walk
cls
echo.
echo Double click "Dino.Walk" to start the program
echo.
pause
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=config1.txt
goto end

:build
cls
echo.
echo Double click "Dino.sys16" to start the program
echo.
pause
..\..\..\util\setconsole.exe /minimize
SET CONFIGTXT=config2.txt
goto end

:end