echo off
SET DISK1=Game.po
SET DISK2=
SET DISKS=1
cd %VAR%
..\..\..\util\setconsole.exe /reset
echo.
echo Once you have selected "Play Game" and the game
echo has started, you need to press Ctrl+r to start
echo player control of the helicopter.
echo.
pause
..\..\..\util\setconsole.exe /minimize