echo off
SET DISK1=disk1.2mg
SET DISK2=
SET DISKS=1
cd %VAR%
